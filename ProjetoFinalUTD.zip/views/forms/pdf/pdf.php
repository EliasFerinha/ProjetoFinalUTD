<?php
	use Dompdf\Dompdf;
	include_once $GLOBALS['project_path']."/views/forms/pdf/dompdf/autoload.inc.php";
	
	$pdf = new Dompdf();

	$html = file_get_contents("http://localhost/ProjetoFinalUTD/views/forms/pdf/produto.php");
	$pdf -> loadHtml($html);
	$pdf -> setPaper("A4", "landingpage");
	$pdf -> render();
	$pdf -> stream();
?>